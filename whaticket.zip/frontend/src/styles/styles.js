export const colorBack = () => {

  return "#0000FF";
};

export const colorPrimary = () => {

  return "#0000FF";
};

export const colorIconesMenu = () => {

  return "#07074a";
};

export const colorTitleTable = () => {

  return "#e5e5e5";
};

export const colorTopTable = () => {

  return "#ededed";
};

export const colorBackgroundTable = () => {

  return "#2a273b";
};

export const colorLineTable = () => {

  return "#0000FF";
};

export const colorLineTableHover = () => {

  return '#07074a';
};

export const colorTopbar = () => {

  return "#141414";
};


